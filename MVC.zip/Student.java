public class Student{
	private String rollNo;
    private String name;

    public String getName() { return name; }
    public void setName(String name1) { name = name1; }
    public String getRollNo() { return rollNo; }
    public void setRollNo(String rollNo1) { rollNo = rollNo1; }
}