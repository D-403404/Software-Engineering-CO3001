public class StudentView{
	public void printStudentDetails(Student stu) { System.out.println("NAME=" + stu.getName() + ",ROLLNO=" + stu.getRollNo()); }
}